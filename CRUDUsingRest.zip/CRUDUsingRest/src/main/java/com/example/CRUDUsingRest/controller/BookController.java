package com.example.CRUDUsingRest.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.CRUDUsingRest.model.Book;
import com.example.CRUDUsingRest.repositary.BookRepo;

@RestController
public class BookController {

	@Autowired
	BookRepo bookRepo;

	@GetMapping("/getAllBooks")
	public ResponseEntity<List<Book>> getAllBooks() {
		List<Book> list = new ArrayList<>();
		bookRepo.findAll().forEach(list::add);

		if (list.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		return new ResponseEntity<List<Book>>(list, HttpStatus.OK);

	}

	@GetMapping("/getBookById/{id}")
	public ResponseEntity<Book> getBookById(@PathVariable Long id) {

		Optional<Book> bookFoundByid = bookRepo.findById(id);

		if (bookFoundByid.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		return new ResponseEntity<Book>(bookFoundByid.get(), HttpStatus.OK);

	}

	@PostMapping("/saveBook") 
	public ResponseEntity<Book> saveBook(@RequestBody Book book) {
		Book savedBook = bookRepo.save(book);

		return new ResponseEntity<Book>(savedBook, HttpStatus.OK);

	}

	@PutMapping("/updateBookById/{id}")
	public ResponseEntity<Book> updateBookById(@PathVariable Long id, @RequestBody Book book) {
		Optional<Book> updateBook = bookRepo.findById(id);
		if (updateBook.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);

		updateBook.get().setAuthor(book.getAuthor());
		updateBook.get().setNoOfPages(book.getNoOfPages());

		return new ResponseEntity<Book>(updateBook.get(), HttpStatus.OK);

	}

	@DeleteMapping("/deleteBookById/{id}")
	public ResponseEntity<HttpStatus> deleteBookById(@PathVariable Long id) {
		bookRepo.deleteById(id);
		return new ResponseEntity<HttpStatus>(HttpStatus.OK);

	}

}
