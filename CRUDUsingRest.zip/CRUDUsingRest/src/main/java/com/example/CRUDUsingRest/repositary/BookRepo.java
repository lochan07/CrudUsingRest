package com.example.CRUDUsingRest.repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.CRUDUsingRest.model.Book;

public interface BookRepo extends JpaRepository<Book, Long> {

}
